  var scotchApp = angular.module('scotchApp', ['ngRoute']);

    // configure our routes
    scotchApp.config(function($routeProvider) {
        $routeProvider

            // route for the home page
            .when('/', {
                templateUrl : '/index.html',
            })

            // route for the about page
            .when('/product', {
                templateUrl : '/product.html',

            })

            // route for the contact page
            .when('/restaurant', {
                templateUrl: '/restaurant.html',
            })
            // route for the about page
            .when('/companie', {
                templateUrl : '/companie.html',

    });
    });

    // create the controller and inject Angular's $scope
    scotchApp.controller('mainController', function($scope) {
        // create a message to display in our view
        $scope.message = 'Everyone come and see how good I look!';
    });

    scotchApp.controller('aboutController', function($scope) {
        $scope.message = 'Look! I am an about page.';
    });

    scotchApp.controller('contactController', function($scope) {
        $scope.message = 'Contact us! JK. This is just a demo.';
    });

(function() {
  "use strict";

  var app = angular.module("testApp", []).factory("PagerService", PagerService);

  //controllers
  app.controller("searchBtnCtrl", [
    "$scope",
    "$http",
    "PagerService",
    function($scope, $http, PagerService) {
      var vm = this;


      $scope.GetValues = function(id, name, price) {
                document.write(id + " " + name + " " +  price);
          };


      $scope.performSearch = function() {
        console.log("clicked");
        $(".post").remove();

        $http
          .get("index.json")
          .then(function(response) {
              $scope.myFavorite = response.data;
             // console.log($scope.myFavorite);
              console.log($scope.myFavorite.data.products);
             vm.itemsToDisplay = $scope.myFavorite.data.products; // array of items to be paged
            vm.pager = {};
            vm.setPage = setPage;

            initController();

            function initController() {
              // initialize to page 1
              vm.setPage(1);
            }

            function setPage(page) {
              if (page < 1 || page > vm.pager.totalPages) {
                return;
              }
              // get pager object from service
              vm.pager = PagerService.GetPager(vm.itemsToDisplay.length, page);

              // get current page of items
              vm.posts = vm.itemsToDisplay.slice(
                vm.pager.startIndex,
                vm.pager.endIndex + 1
              );
            }
          });
      };
    }
  ]);


function PagerService() {
    // service definition
    var service = {};

    service.GetPager = GetPager;

    return service;

    // service implementation
    function GetPager(totalItems, currentPage, pageSize) {
      // default to first page
      currentPage = currentPage || 1;

      // default page size is 10
      pageSize = pageSize || 5;

      // calculate total pages
      var totalPages = Math.ceil(totalItems / pageSize);

      var startPage, endPage;
      if (totalPages <= 5) {
         // less than 10 total pages so show all
        startPage = 1;
        endPage = totalPages;
      } else {
        // more than 10 total pages so calculate start and end pages
        if (currentPage <= 4) {
          startPage = 1;
          endPage = 5;
        } else if (currentPage + 4 >= totalPages) {
          startPage = totalPages - 4;
          endPage = totalPages;
        } else {
          startPage = currentPage - 2;
          endPage = currentPage + 3;
        }
      }
      // calculate start and end item indexes
      var startIndex = (currentPage - 1) * pageSize;
      var endIndex = Math.min(startIndex + pageSize - 1, totalItems - 1);

      // create an array of pages to ng-repeat in the pager control
      var pages = _.range(startPage, endPage + 1);

      // return object with all pager properties required by the view
      return {
        totalItems: totalItems,
        currentPage: currentPage,
        pageSize: pageSize,
        totalPages: totalPages,
        startPage: startPage,
        endPage: endPage,
        startIndex: startIndex,
        endIndex: endIndex,
        pages: pages
      };
    }
  }
})();

