'use strict';

describe('myApp.services module', function() {

  beforeEach(module('myApp.services'));

  describe('services controller', function(){

    it('should ....', inject(function($controller) {
      //spec body
      var servicesCtrl = $controller('ServicesCtrl');
      expect(servicesCtrl).toBeDefined();
    }));

  });
});