'use strict';

describe('myApp.work module', function() {

  beforeEach(module('myApp.work'));

  describe('work controller', function(){

    it('should ....', inject(function($controller) {
      //spec body
      var workCtrl = $controller('WorkCtrl');
      expect(workCtrl).toBeDefined();
    }));

  });
});