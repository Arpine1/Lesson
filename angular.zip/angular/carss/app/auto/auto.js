'use strict';


angular.module('myApp.auto', ['ngRoute'])

    .config(['$routeProvider', function($routeProvider) {
        $routeProvider.when('/auto', {
            templateUrl: 'auto/auto.html',
            controller: 'UsersCtrl'
        });
    }])
    .controller('UsersCtrl', ['$scope', '$http', function($scope, $http) {
        $http.get("http://127.0.0.1:8080/api/user_list")
            .then(function(response) {
                $scope.users = response.data;
            });

        $scope.addUsers = function(){

            var url = "http://127.0.0.1:8080/userData";

            var dataUsers =
                {
                    firstName:$scope.firstName,
                    lastName:$scope.lastName,
                    email : $scope.email,
                    password : $scope.password
                };

            $http.post(url, dataUsers)
                .then(function(httpRequest) {
                    //console.log(httpRequest);
                });
        };


        $scope.editUser = function (id) {
            console.log(id);

            var url = "http://127.0.0.1:8080/update/userData";

            var dataId =
                {
                    id: id
                };

            $http.post(url,dataId)
                .then(function(httpRequest) {
                    //console.log(httpRequest);
                });
        };

        $scope.deleteUser = function (id) {
            console.log(id);


            var url = "http://127.0.0.1:8080/delete/userData";

            var dataId =
                {
                    id: id
                };

            $http.post(url,dataId)
                .then(function(httpRequest) {
                    //console.log(httpRequest);
                });
        };
    }]);

