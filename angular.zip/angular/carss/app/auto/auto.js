'use strict';


angular.module('myApp.auto', ['ngRoute'])

    .config(['$routeProvider', function($routeProvider) {
        $routeProvider.when('/auto', {
            templateUrl: 'auto/auto.html',
            controller: 'UsersCtrl'
        });
    }])

    .controller('UsersCtrl', ['$scope', '$http', function($scope, $http) {
        $scope.addUsers = function(){

            var url = "http://127.0.0.1:8080/api/car";

            var dataUsers =
                {
                    email : $scope.email,
                    password : $scope.password
                };

            $http.post(url, dataUsers)
                .then(function(httpRequest) {
                    //console.log(httpRequest);
                });
        };
    }]);