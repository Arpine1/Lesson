'use strict';

angular.module('myApp.Update', ['ngRoute'])

    .config(['$routeProvider', function($routeProvider) {
        $routeProvider.when('/Update', {
            templateUrl: 'Update/Update.html',
            controller: 'UpdateCtrl'
        });
    }])
    .controller('UpdateCtrl', ['$scope', '$http', '$location', function($scope, $http, $location) {
        console.log($location.$$search.id)
        $scope.updateUsers = function(){

            var urlDelete = "http://127.0.0.1:8080/update/userData";
            var dataUpdate =
                {
                    id: $location.$$search.id,
                    firstName:$scope.firstName,
                    lastName:$scope.lastName,
                    email: $scope.email,
                    password : $scope.password
                };

            $http.post(urlDelete, dataUpdate)
                .then(function(httpRequest) {
                    // console.log(httpRequest.status + "OK");
                    console.log($location.$$search.id)
                });
        };

    }]);

