'use strict';

angular.module('myApp.home', ['ngRoute'])

    .config(['$routeProvider', function($routeProvider) {
        $routeProvider.when('/home', {
            templateUrl: 'home/home.html',
            controller: 'HomeCtrl'
        });
    }])

    .controller('HomeCtrl', function($scope, $http) {

        $scope.funcSave = function()
        {
            if($scope.myForm.$valid) {
                alert(" is Valid...");
            }
            else
            {
                alert(" is not Valid...");
                return false;
            }

        }



        $scope.addCars = function(){
            $scope.dataCars = [
                {
                    cars_name : $scope.cars_name,
                    cars_price : $scope.cars_price,
                    cars_year : $scope.cars_year,
                    cars_transmission : $scope.cars_transmission,
                    cars_useWay : $scope.cars_useWay,
                    cars_make : $scope.cars_make

                }
            ];
            console.log( $scope.dataCars);
        }


    })